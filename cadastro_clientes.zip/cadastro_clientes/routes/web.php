<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/cliente/cadastro', 'ClientesController@cadastro');
Route::post('/cliente/new', 'ClientesController@cadastrarCliente')->name('cadastrar_cliente');
Route::get('/cliente/lista', 'ClientesController@listarCliente');