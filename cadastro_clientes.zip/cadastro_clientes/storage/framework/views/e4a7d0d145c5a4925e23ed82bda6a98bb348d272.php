<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link rel="icon" type="imagem/png" href="<?php echo e(url('image/icon.png')); ?>" />
	<title>FraiBeer</title>

	<link rel="stylesheet" type="text/css" href="<?php echo e(url('style/style.css')); ?>"/>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<body>

<div class="container-fluid">
	<div class="row">
		
		<nav class="navbar navbar-expand-lg navbar-dark bg-dark col-md-12">
		  <a class="navbar-brand" href="#"><img src="<?php echo e(url('image/icon.png')); ?>" height="50" class="d-inline-block align-top" alt=""><span class="fontBeer">FraiBeer</span></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="navbarNavDropdown">
		    <ul class="navbar-nav">
		      <li class="nav-item">
		        <a class="nav-link" href="#">Produtos</a>
		      </li>
		      <li class="nav-item active">
		        <a class="nav-link" href="#">Cadastre-se<span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="/cliente/lista">Lista de Clientes</a>
		      </li>
		    </ul>
		  </div>
		  
			<div class="dropdown dropleft">
			  <button class="btn btn-dark my-2 my-sm-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			    Login
			  </button>
			  <div class="dropdown-menu dropdown-menu-left" aria-labelledby="dropdownMenuButton">
			    <form class="px-4 py-3">
				    <div class="form-group">
				      <label for="email">Endereço de e-mail</label>
				      <input type="email" class="form-control" id="email" placeholder="email@example.com">
				    </div>
				    <div class="form-group">
				      <label for="password1">Password</label>
				      <input type="password" class="form-control" id="password1" placeholder="Password">
				    </div>

				    <button type="submit" class="btn btn-primary">Entrar</button>
				  </form>
				  <div class="dropdown-divider"></div>
				  <a class="dropdown-item" href="/cliente/cadastro">Novo por aqui? Cadastre-se</a>
				  <a class="dropdown-item" href="#">Esqueceu sua senha?</a>
				</div>
			  </div>
			</div>
		

		</nav>

		<div class="mt-4 col-md-12">
			<h1>Realize seu cadastro</h1>
			<h6>Para acessar área do cliente e promoções!</h6>
		</div>


		<div class="col-md-1"></div>
		<div class="col-md-10 mt-3">
			<form method="POST" action="<?php echo e(Route('cadastrar_cliente')); ?>">
				<?php echo csrf_field(); ?>
			  <div class="form-row">
			    <div class="form-group col-md-6">
			      <label for="email">Email</label>
			      <input required="true" type="email" class="form-control" name="email">
			    </div>
			    <div class="form-group col-md-6">
			      <label for="senha">Senha</label>
			      <input required="true" type="password" class="form-control" name="senha">
			    </div>
			  </div>
			   <div class="form-group">
			    <label for="nome">Nome</label>
			    <input required="true" type="text" class="form-control" name="nome" placeholder="João da Silva">
			  </div>
			  <div class="form-group">
			    <label for="endereco">Endereço</label>
			    <input required="true" type="text" class="form-control" name="endereco" placeholder="Av Exemplo 12">
			  </div>
			  <div class="form-row">
			    <div class="form-group col-md-6">
			      <label for="cidade">Cidade</label>
			      <input required="true" type="text" class="form-control" name="cidade">
			    </div>
			    <div class="form-group col-md-4">
			      <label for="estado">Estado</label>
			      <select name="estado" class="form-control">
			        	<option value="AC">Acre</option>
						<option value="AL">Alagoas</option>
						<option value="AP">Amapá</option>
						<option value="AM">Amazonas</option>
						<option value="BA">Bahia</option>
						<option value="CE">Ceará</option>
						<option value="DF">Distrito Federal</option>
						<option value="ES">Espírito Santo</option>
						<option value="GO">Goiás</option>
						<option value="MA">Maranhão</option>
						<option value="MT">Mato Grosso</option>
						<option value="MS">Mato Grosso do Sul</option>
						<option value="MG">Minas Gerais</option>
						<option value="PA">Pará</option>
						<option value="PB">Paraíba</option>
						<option value="PR">Paraná</option>
						<option value="PE">Pernambuco</option>
						<option value="PI">Piauí</option>
						<option value="RJ">Rio de Janeiro</option>
						<option value="RN">Rio Grande do Norte</option>
						<option value="RS">Rio Grande do Sul</option>
						<option value="RO">Rondônia</option>
						<option value="RR">Roraima</option>
						<option value="SC">Santa Catarina</option>
						<option value="SP">São Paulo</option>
						<option value="SE">Sergipe</option>
						<option value="TO">Tocantins</option>
			      </select>
			    </div>
			    <div class="form-group col-md-2">
			      <label for="cep">CEP</label>
			      <input type="text" class="form-control" name="cep">
			    </div>
			  </div>
			  <div class="form-group">
			    <div class="form-check">
			      <input required="true" class="form-check-input" type="checkbox" id="gridCheck">
			      <label class="form-check-label" for="gridCheck">
			        Verificar
			      </label>
			    </div>
			  </div>
			  <button type="submit" class="btn btn-primary">Cadastrar</button>
			</form>
		</div>
		<div class="col-md-1"></div>
	</div>
</div>






<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\cadastro_clientes\resources\views/cadastro.blade.php ENDPATH**/ ?>